
$(document).ready(function () {
    var table = $('<table class="table table-bordered"></table>').appendTo("#table-container");

    if ($("#table-container table").length === 0) {
        table.append('<tr><th>Gusto</th><th>Porcentaje</th><th>Editar</th></tr>');
    }

    $("#btnNuevo").click(function () {
        var nuevoGusto = $('#gustoid').val();
        
        var row = $('<tr></tr>').appendTo(table);
        var gustoCell = '<td><input type="text" class="form-control" name="gusto" value="' + nuevoGusto + '" disabled></td>';
        var porcentajeCell = '<td><input type="text" class="form-control" name="porcentaje" value="0" disabled></td>';
        var editarCell = '<td><label class="editar-label">Editar</label></td>';
        row.append(gustoCell + porcentajeCell + editarCell);

        var buttonContainer = $('<div class="button-container"></div>').appendTo("#table-container");
        var editMessage = $('<span class="edit-message" style="display:none">Pulse guardar para aceptar los cambios o cancelar para anularlos</span>').appendTo(buttonContainer);

        var guardarCancelarButtons = row.find('.guardar-cancelar-buttons');

        $('#gustoid').val('');

        $('.editar-label').click(function () {
            var row = $(this).closest('tr');
            row.find('input[name="gusto"], input[name="porcentaje"]').prop('disabled', false);
            if (guardarCancelarButtons.length === 0) {
                guardarCancelarButtons = $('<div class="guardar-cancelar-buttons"></div>').appendTo("#table-container");
                guardarCancelarButtons.append('<button class="btn btn-success guardar-btn">Guardar</button>');
                guardarCancelarButtons.append('<button class="btn btn-danger cancelar-btn">Cancelar</button>');
          
            }
            editMessage.show();
            guardarCancelarButtons.show();

        });

        $('#table-container').on('click', '.guardar-btn', function () {
        var row = $(this).closest('tr');
        var gusto = row.find('input[name="gusto"]').val();
        var porcentaje = row.find('input[name="porcentaje"]').val();
        window.location.href = 'resultados.html' + '?gusto=' + gusto + '&porcentaje=' + porcentaje;
        });

        $('#table-container').on('click', '.cancelar-btn', function () {
            var row = $(this).closest('tr');
            row.find('input[name="gusto"]').val(row.find('input[name="gusto"]').data('original-value'));
            row.find('input[name="gusto"], input[name="porcentaje"]').prop('disabled', true);
            
            editMessage.hide();
            guardarButton.hide();
            cancelarButton.hide();
        });
    });
});
